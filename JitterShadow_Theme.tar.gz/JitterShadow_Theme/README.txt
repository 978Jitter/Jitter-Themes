JITTER-SHADOW  -  Kali Linux ARM (XFCE)
Install:   tar xzf Jitter-Shadow.tar.gz && cd pkg && bash install.sh
Uninstall: bash uninstall.sh
Contents:  xfwm4 window frame (angled corners, stripe detail, red active highlight,
           pentagram menu button, min/max/close), GTK3 + GTK2 theme, XFCE panel
           styling, terminal colours + JetBrains Mono, jitter@5H4D0W prompt, wallpaper.
Note: all frame images are fully opaque, so this works with compositing on or off.
Panel: bash install-panel.sh  (undo: bash uninstall-panel.sh)
