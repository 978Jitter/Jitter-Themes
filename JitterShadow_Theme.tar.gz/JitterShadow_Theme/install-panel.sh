#!/usr/bin/env bash
# Jitter-Shadow panel + start menu (run after install.sh, as normal user)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
T=Jitter-Shadow
echo "[*] Updating theme files..."
rm -rf ~/.themes/$T && cp -r "$HERE/$T" ~/.themes/$T
mkdir -p ~/.local/share/icons && cp -r "$HERE/extras/icons/hicolor" ~/.local/share/icons/ 
gtk-update-icon-cache -f -t ~/.local/share/icons/hicolor 2>/dev/null || true
BG="$HOME/.themes/$T/panel/panel-bg.png"

xset() { xfconf-query -c "$1" -p "$2" -n -t "$3" -s "$4" 2>/dev/null || xfconf-query -c "$1" -p "$2" -s "$4"; }
echo "[*] Styling panels..."
for p in $(xfconf-query -c xfce4-panel -l 2>/dev/null | grep -E '^/panels/panel-[0-9]+/size$' | sed 's#/size$##'); do
  xset xfce4-panel $p/size uint 36
  xset xfce4-panel $p/icon-size uint 0
  xset xfce4-panel $p/background-style uint 2
  xset xfce4-panel $p/background-image string "$BG"
  echo "    $p ok"
done

echo "[*] Configuring Whisker start menu..."
found=0
setkey() { f="$1"; k="$2"; v="$3"; if grep -q "^$k=" "$f"; then sed -i "s|^$k=.*|$k=$v|" "$f"; else echo "$k=$v" >> "$f"; fi; }
for f in ~/.config/xfce4/panel/whiskermenu-*.rc; do
  [ -f "$f" ] || continue
  found=1; cp "$f" "$f.bak"
  setkey "$f" button-icon jitter-menu
  setkey "$f" button-title JITTER
  setkey "$f" show-button-title true
  setkey "$f" show-button-icon true
  setkey "$f" menu-width 520
  setkey "$f" menu-height 560
  setkey "$f" menu-opacity 100
  setkey "$f" category-icon-size 1
  setkey "$f" item-icon-size 2
  setkey "$f" launcher-show-description false
  setkey "$f" position-search-alternate true
  setkey "$f" profile-shape 0
  echo "    patched $f"
done
[ $found = 0 ] && echo "    (no whiskermenu-*.rc found: right-click your menu button > Properties > Appearance and set icon 'jitter-menu', title JITTER)"

echo "[*] Restarting panel..."
xfce4-panel -r >/dev/null 2>&1 || true
echo "[+] Done."
