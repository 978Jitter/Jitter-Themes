#!/usr/bin/env bash
for p in $(xfconf-query -c xfce4-panel -l | grep -E '^/panels/panel-[0-9]+/background-style$'); do xfconf-query -c xfce4-panel -p $p -s 0; done
for f in ~/.config/xfce4/panel/whiskermenu-*.rc.bak; do [ -f "$f" ] && mv "$f" "${f%.bak}"; done
xfce4-panel -r
