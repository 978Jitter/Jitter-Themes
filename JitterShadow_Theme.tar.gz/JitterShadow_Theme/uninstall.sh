#!/usr/bin/env bash
rm -rf ~/.themes/Jitter-Shadow
xfconf-query -c xfwm4 -p /general/theme -s Default 2>/dev/null
xfconf-query -c xsettings -p /Net/ThemeName -s Kali-Dark 2>/dev/null || xfconf-query -c xsettings -p /Net/ThemeName -s Adwaita-dark
[ -f ~/.config/xfce4/terminal/terminalrc.bak ] && mv ~/.config/xfce4/terminal/terminalrc.bak ~/.config/xfce4/terminal/terminalrc
echo "Reverted. Remove the 5H4D0W prompt lines from ~/.zshrc / ~/.bashrc manually if desired."
