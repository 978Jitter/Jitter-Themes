#!/usr/bin/env bash
# Jitter-Shadow installer for Kali Linux (ARM) - XFCE
# Run as your normal user:  bash install.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
T="Jitter-Shadow"
echo "[*] Installing fonts + tools (needs sudo)..."
sudo apt-get update -y || true
sudo apt-get install -y fonts-jetbrains-mono xfce4-terminal libglib2.0-bin x11-xserver-utils || true

echo "[*] Installing theme to ~/.themes ..."
mkdir -p ~/.themes ~/Pictures
rm -rf ~/.themes/$T
cp -r "$HERE/$T" ~/.themes/$T
mkdir -p ~/.themes/$T/xfwm4
cp "$HERE/extras/jitter-wallpaper.png" ~/Pictures/

xset() { xfconf-query -c "$1" -p "$2" -n -t "$3" -s "$4" 2>/dev/null || xfconf-query -c "$1" -p "$2" -s "$4"; }
echo "[*] Applying window manager theme..."
xset xfwm4 /general/theme string "$T"
xset xfwm4 /general/button_layout string "O|HMC"
xset xfwm4 /general/title_alignment string "left"
xset xfwm4 /general/title_font string "JetBrains Mono Bold 10"

echo "[*] Applying GTK theme + fonts..."
xset xsettings /Net/ThemeName string "$T"
xset xsettings /Gtk/FontName string "JetBrains Mono 10"
xset xsettings /Gtk/MonospaceFontName string "JetBrains Mono 10"
xset xsettings /Gtk/CursorThemeName string "Adwaita"

echo "[*] Terminal colours + prompt..."
mkdir -p ~/.config/xfce4/terminal
[ -f ~/.config/xfce4/terminal/terminalrc ] && cp ~/.config/xfce4/terminal/terminalrc ~/.config/xfce4/terminal/terminalrc.bak
cp "$HERE/extras/terminalrc" ~/.config/xfce4/terminal/terminalrc
for rc in ~/.zshrc ~/.bashrc; do
  [ -f "$rc" ] && ! grep -q "5H4D0W" "$rc" && { echo "" >> "$rc"; cat "$HERE/extras/prompt.sh" >> "$rc"; }
done

echo "[*] Wallpaper..."
for p in $(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep last-image); do
  xfconf-query -c xfce4-desktop -p "$p" -s "$HOME/Pictures/jitter-wallpaper.png"
done

echo "[*] Reloading window manager..."
(xfwm4 --replace >/dev/null 2>&1 &) ; sleep 1
echo "[+] Done. If anything looks off, log out and back in."
echo "    Manual path: Settings > Window Manager > Style > Jitter-Shadow"
echo "                 Settings > Appearance > Style > Jitter-Shadow"
