# Jitter prompt:  jitter@5H4D0W:~$   (red user, white host)
if [ -n "$ZSH_VERSION" ]; then
  PROMPT='%F{red}jitter%f%F{white}@5H4D0W:%~$ %f'
elif [ -n "$BASH_VERSION" ]; then
  PS1='\[\e[1;31m\]jitter\[\e[0m\]@5H4D0W:\w$ '
fi
